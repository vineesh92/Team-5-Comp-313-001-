package com.restaurant.group.restauranthub;

/**
 * Created by ${Abhi} on 8/24/2018.
 */

public class AppController {
    public static final String WEB_SERVICE_URL = "http://www.mocky.io/v2/";
    public static final String END_POINT_LOGIN = "5b991b773200002a0013fbfe";
    public static final String END_POINT_REGISTER = "5b84e1313000007600728f2f";
    public static final String END_POINT_RESTAURANTS_LIST = "5bfe43c831000081002cfcdb";
    public static final String END_POINT_RESTAURANTS_DETAILS= "5bfe454831000081002cfceb";
    public static final String END_POINT_RESTAURANTS_GET_AVAILABLE_TIME= "5b9f60c83000005800e28ca9";
    public static final String END_POINT_MY_ACCOUNT= "5bfe502231000054412cfd20";
    public static final String END_POINT_UPDATE_MY_PROFILE= "5b890fb930000053103382ba";
    public static final String END_POINT_MY_BOOKINGS= "5bfe46ee31000070002cfcf3";
    public static final String END_POINT_FORGOT_PASSWORD= "5b9faab130000058007b12b4";
    public static final String END_POINT_RESET_PASSWORD= "5b863d8e34000029048b546e";
    public static final String APP_TITLE= "EasyBite";
}
